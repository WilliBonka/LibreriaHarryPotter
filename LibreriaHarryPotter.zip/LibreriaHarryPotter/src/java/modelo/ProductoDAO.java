/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import config.Conexion;
import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author WilliBonka
 */
public class ProductoDAO {
    Connection con;
    Conexion cn=new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    
    public Producto ListIsbn (int isbn){
        String sql="select * from libros where isbn="+isbn;        
        Producto p=new Producto();
        try{
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while (rs.next()){                
                p.setIsbn(rs.getInt(1));
                p.setTitulo(rs.getString(2));
                p.setAutor(rs.getString(3));
                p.setEditorial(rs.getString(4));
                p.setPublicacion(rs.getInt(5));
                p.setPaginas(rs.getInt(6));
                p.setFoto(rs.getBinaryStream(7));
                p.setPrecio(rs.getInt(8));          
                p.setStock(rs.getInt(9));                
            }
        } catch (Exception e) {            
        }
        return p;
    }
    
    public List listar(){
        List<Producto>productos=new ArrayList();
        String sql="select * from libros";
        try{
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while (rs.next()){
                Producto lib=new Producto();
                lib.setIsbn(rs.getInt(1));
                lib.setTitulo(rs.getString(2));
                lib.setAutor(rs.getString(3));
                lib.setEditorial(rs.getString(4));
                lib.setPublicacion(rs.getInt(5));
                lib.setPaginas(rs.getInt(6));
                lib.setFoto(rs.getBinaryStream(7));
                lib.setPrecio(rs.getInt(8));
                lib.setStock(rs.getInt(9));                
                productos.add(lib);
            }
        } catch (Exception e) {            
        }
        return productos;
    }
    
    //Manejo de imagenes de los productos
    public void listarImg(int isbn, HttpServletResponse response){
        String sql="select foto from libros where isbn="+isbn;
        InputStream inputStream=null;
        OutputStream outpuStream=null;
        BufferedInputStream bufferedInputStream=null;
        BufferedOutputStream bufferedOutputStream=null;
        try {
            outpuStream=response.getOutputStream();
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            if(rs.next()){
                inputStream=rs.getBinaryStream("foto");
            }
            bufferedInputStream=new BufferedInputStream(inputStream);
            bufferedOutputStream=new BufferedOutputStream(outpuStream);
            int i=0;
            while ((i=bufferedInputStream.read())!=-1){
                bufferedOutputStream.write(i);
            }
        } catch (Exception e){
        }
    }
    
    public void ActualizaCantidades (int isbn, int cantidad){
        String sql="update libros set stock='"+ cantidad +"' where isbn="+isbn;
        try{
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();            
        } catch (Exception e) {            
        }
    }
}
