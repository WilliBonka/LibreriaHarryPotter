package modelo;
import java.io.InputStream;
/**
 *
 * @author WilliBonka
 * Definicion de las propiedades del producto, campos de la tabla libros
 */
public class Producto {
    int isbn;
    String titulo;
    String autor;
    String editorial;
    int publicacion;
    int paginas;
    InputStream foto;
    int precio;
    int stock;
    int preCantidad;

    public Producto() {
    }

    public Producto(int isbn, String titulo, String autor, String editorial, int publicacion, int paginas, InputStream foto, int precio, int stock, int preCantidad) {
        this.isbn = isbn;
        this.titulo = titulo;
        this.autor = autor;
        this.editorial = editorial;
        this.publicacion = publicacion;
        this.paginas = paginas;
        this.foto = foto;
        this.precio = precio;
        this.stock = stock;
        this.preCantidad = preCantidad;
    }

    public int getIsbn() {
        return isbn;
    }

    public void setIsbn(int isbn) {
        this.isbn = isbn;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public int getPublicacion() {
        return publicacion;
    }

    public void setPublicacion(int publicacion) {
        this.publicacion = publicacion;
    }

    public int getPaginas() {
        return paginas;
    }

    public void setPaginas(int paginas) {
        this.paginas = paginas;
    }

    public InputStream getFoto() {
        return foto;
    }

    public void setFoto(InputStream foto) {
        this.foto = foto;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public int getPreCantidad() {
        return preCantidad;
    }

    public void setPreCantidad(int preCantidad) {
        this.preCantidad = preCantidad;
    }
}