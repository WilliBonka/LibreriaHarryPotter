/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author WilliBonka
 */
public class Carrito {
    int item;
    int isbn;
    String Titulo;
    double precio;
    int cantidad;
    double subtotal;
    int stock;

    public Carrito() {
    }

    public Carrito(int item, int isbn, String Titulo, double precio, int cantidad, double subtotal, int stock) {
        this.item = item;
        this.isbn = isbn;
        this.Titulo = Titulo;
        this.precio = precio;
        this.cantidad = cantidad;
        this.subtotal = subtotal;
        this.stock = stock;
    }

    public int getItem() {
        return item;
    }

    public void setItem(int item) {
        this.item = item;
    }

    public int getIsbn() {
        return isbn;
    }

    public void setIsbn(int isbn) {
        this.isbn = isbn;
    }

    public String getTitulo() {
        return Titulo;
    }

    public void setTitulo(String Titulo) {
        this.Titulo = Titulo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

}
