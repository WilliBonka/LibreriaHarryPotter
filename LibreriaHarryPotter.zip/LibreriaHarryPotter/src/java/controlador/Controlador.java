/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Carrito;
import modelo.Producto;
import modelo.ProductoDAO;

/**
 *
 * @author WilliBonka
 */
public class Controlador extends HttpServlet {
    
    ProductoDAO pdao=new ProductoDAO();
    Producto p=new Producto();    
    List<Producto>productos=new ArrayList<>();    
    List<Carrito>listacarrito= new ArrayList<>();
    int item;
    double totalPagar=0.0;
    int cantidad=1;
    int precantidad=0;
    int stock=0;
    int pos=0;
    
    int isbn;
    Carrito car;   
    
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            String accion=request.getParameter("accion");
            productos=pdao.listar(); 
            
            
            switch (accion){
               case "Comprar":
                   totalPagar=0.0;
                   isbn=Integer.parseInt(request.getParameter("id"));
                   cantidad=Integer.parseInt(request.getParameter("precantidad"));
                   p=pdao.ListIsbn(isbn);                  
                   
                   
                   if (cantidad > p.getStock()){
                       request.setAttribute("CompCacelada","Los elementos exceden el inventario disponible.");
                   }else{ 
                   if(listacarrito.size() > 0){                                                
                        for (int i = 0; i < listacarrito.size(); i++){
                            if(isbn==listacarrito.get(i).getIsbn()){
                                pos=i;
                            }
                        }
                            if(isbn==listacarrito.get(pos).getIsbn()){
                                precantidad=listacarrito.get(pos).getCantidad()+cantidad;
                                if (precantidad <= p.getStock()){
                                    cantidad=listacarrito.get(pos).getCantidad()+cantidad;
                                    double subtotal=listacarrito.get(pos).getPrecio()*cantidad;
                                    listacarrito.get(pos).setCantidad(cantidad);
                                    listacarrito.get(pos).setSubtotal(subtotal);
                                    request.setAttribute("mensajeError","");
                                }else{
                                    request.setAttribute("mensajeError","Los elementos exceden el inventario disponible.");
                                }
                            }else{
                                 item=item+1;
                                 car=new Carrito();
                                 car.setItem(item);
                                 car.setIsbn(p.getIsbn());
                                 car.setTitulo(p.getTitulo());
                                 car.setPrecio(p.getPrecio());
                                 car.setCantidad(cantidad);
                                 car.setSubtotal(cantidad*p.getPrecio());
                                 car.setStock(p.getStock());
                                 listacarrito.add(car);
                            }
                    }else{
                         item=item+1;
                         car=new Carrito();
                         car.setItem(item);
                         car.setIsbn(p.getIsbn());
                         car.setTitulo(p.getTitulo());
                         car.setPrecio(p.getPrecio());
                         car.setCantidad(cantidad);
                         car.setSubtotal(cantidad*p.getPrecio());  
                         car.setStock(p.getStock());
                         listacarrito.add(car);
                    }
                   }
                   for (int i=0;i<listacarrito.size();i++){
                       totalPagar=totalPagar+listacarrito.get(i).getSubtotal();                       
                   }                   
                   request.setAttribute("totalPagar",totalPagar);
                   request.setAttribute("basecarrito",listacarrito);
                   request.setAttribute("contador",listacarrito.size());
                   request.getRequestDispatcher("carrito.jsp").forward(request,response);
                       break;
               case "AgregarCarrito":                   
                   isbn=Integer.parseInt(request.getParameter("id"));
                   cantidad=Integer.parseInt(request.getParameter("precantidad"));
                   p=pdao.ListIsbn(isbn);                 
                   
                   System.out.print(cantidad);
                   if (cantidad > p.getStock()){
                       request.setAttribute("mensajeError","Los elementos exceden el inventario disponible.");
                   }else{
                       
                   if(listacarrito.size() > 0){   
                       
                        for (int i = 0; i < listacarrito.size(); i++){
                            if(isbn==listacarrito.get(i).getIsbn()){
                                pos=i;
                            }
                        }
                            if(isbn==listacarrito.get(pos).getIsbn()){
                                precantidad=listacarrito.get(pos).getCantidad()+cantidad;
                                if (precantidad > p.getStock()){
                                    request.setAttribute("mensajeError","Los elementos exceden el inventario disponible.");
                                }else{
                                    cantidad=listacarrito.get(pos).getCantidad()+cantidad;
                                    double subtotal=listacarrito.get(pos).getPrecio()*cantidad;
                                    listacarrito.get(pos).setCantidad(cantidad);
                                    listacarrito.get(pos).setSubtotal(subtotal);
                                    request.setAttribute("mensajeError","");
                                }                                
                            }else{                                
                                 item=item+1;
                                 car=new Carrito();
                                 car.setItem(item);
                                 car.setIsbn(p.getIsbn());
                                 car.setTitulo(p.getTitulo());
                                 car.setPrecio(p.getPrecio());
                                 car.setCantidad(cantidad);
                                 car.setSubtotal(cantidad*p.getPrecio());
                                 car.setStock(p.getStock());
                                 listacarrito.add(car);
                                 
                            }
                    }else{
                       
                         item=item+1;
                         car=new Carrito();
                         car.setItem(item);
                         car.setIsbn(p.getIsbn());
                         car.setTitulo(p.getTitulo());
                         car.setPrecio(p.getPrecio());
                         car.setCantidad(cantidad);
                         car.setSubtotal(cantidad*p.getPrecio());  
                         car.setStock(p.getStock());
                         listacarrito.add(car);                         
                    }
                   }
                   request.setAttribute("contador",listacarrito.size());
                   request.getRequestDispatcher("Controlador?accion=home").forward(request,response);
                   break;
               case "Delete":
                   int idproducto=Integer.parseInt(request.getParameter("isbn"));
                   for (int i = 0; i < listacarrito.size(); i++){
                       if(listacarrito.get(i).getIsbn()==idproducto){
                           listacarrito.remove(i);
                       }
                   }
                   break;
                case "DeleteAll":                   
                    listacarrito.clear();                      
                    request.setAttribute("contador",listacarrito.size());
                    request.setAttribute("totalPagar", "Su carro se encuentra vacio");
                   break;
               case "ActualziarCantidad":
                   int idprod=Integer.parseInt(request.getParameter("isbn2"));
                   int cant=Integer.parseInt(request.getParameter("cantidad"));
                   for (int i = 0; i < listacarrito.size(); i++){
                       if(listacarrito.get(i).getIsbn()==idprod){
                           listacarrito.get(i).setCantidad(cant);
                           double st=listacarrito.get(i).getPrecio()*cant;
                           listacarrito.get(i).setSubtotal(st);
                       }
                   }
                   break;

               case "Carrito": 
                   totalPagar=0.0;
                   request.setAttribute("basecarrito", listacarrito);
                   for (int i=0;i<listacarrito.size();i++){
                       totalPagar=totalPagar+listacarrito.get(i).getSubtotal();                       
                   }
                   request.setAttribute("totalPagar", totalPagar);
                   request.getRequestDispatcher("carrito.jsp").forward(request,response);                   
                   break; 
               case "CarritoVacio":
                   totalPagar=0;
                   request.setAttribute("totalPagar", totalPagar);
                   request.setAttribute("CompCacelada", "¡Su compra se ha cancelado!");
                   request.getRequestDispatcher("carrito.jsp").forward(request,response);                   
                   break;
               case "FinalizaCompra":                          
                   int actStok=0;
                   request.setAttribute("mensajePedidoOk","Hemos recibido su solicitud y será procesada por nuestros agentes. Gracias por su compra.");
                   for (int i = 0; i < listacarrito.size(); i++){
                           isbn=listacarrito.get(i).getIsbn();
                           p=pdao.ListIsbn(isbn);                           
                           actStok = p.getStock() - listacarrito.get(i).getCantidad();                           
                           pdao.ActualizaCantidades(listacarrito.get(i).getIsbn(),actStok);  
                   }                                                        
                   totalPagar=0;
                   listacarrito.clear();                      
                   request.setAttribute("contador",listacarrito.size());     
                   request.getRequestDispatcher("Controlador?accion=home").forward(request, response);
                  // request.setAttribute("totalPagar", totalPagar);
                  // request.setAttribute("CompCacelada", "¡Su compra se ha cancelado!");
                  // request.getRequestDispatcher("carrito.jsp").forward(request,response);                   
                   break;
               default:
                   request.setAttribute("contador",listacarrito.size());
                   request.setAttribute("productos", productos);
                   request.getRequestDispatcher("libros.jsp").forward(request, response);
            }
                   
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}