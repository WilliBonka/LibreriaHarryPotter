/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function(){
    
    $("tr #btndelete").click(function(){
        var isbn=$(this).parent().find("#isbn").val();
        
       swal({
        title: "¿Está Seguro de Eliminar el Producto?",
        text: "Una vez eliminado, usted puede volver a agregar el producto.",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
      .then((willDelete) => {
        if (willDelete) {
          eliminar(isbn);
          swal("El producto fue eliminado del carrito!", {
            icon: "success",
          }).then((willDelete)=>{
              if(willDelete){
                  parent.location.href="Controlador?accion=Carrito";
              }
          });
        } else {
          swal("El producto no fue eliminado del carrito!");
        }
      });        
    });
    
    $("#btnborrarTodo").click(function(){        
        swal({
        title: "¿Desea vaciar el Carrito?",
        text: "Tendrá que seleccionar de nuevo todos los productos .",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
      .then((willDelete) => {
        if (willDelete) {          
          swal("El carrito está vacío!", {
            icon: "success",
          }).then((willDelete)=>{
              if(willDelete){
                  eliminarTodo();
                  parent.location.href="Controlador?accion=CarritoVacio";
              }
          });
        } else {
          swal("El carrito está intacto!");
        }
      });
    });
    
    
    $("#ConfirmComprar").click(function(){        
        swal({
        title: "Confirmar Compra",
        text: "¿Está seguro que desea confirmar la compra?",
        icon: "info",
        buttons: true,
        dangerMode: true,
      })
      .then((willDelete) => {
        if (willDelete) {          
          swal("Felicidades, la compra ha sido confirmada!", {
            icon: "success",
          }).then((willDelete)=>{
              if(willDelete){                  
                  parent.location.href="Controlador?accion=FinalizaCompra";
              }
          });
        } else {
          swal("El carrito está intacto!");
        }
      });
    });
       
   
    function eliminar(isbn){        
        
        var url="Controlador?accion=Delete";
        $.ajax({
            type:'POST',
            url:url,
            data:"isbn="+isbn,
            success:function(data,textStatus,jqXHR){                
            }
        });
    };
    
    function eliminarTodo(){        
        var url="Controlador?accion=DeleteAll";
        $.ajax({
            type:'POST',
            url:url,            
            success:function(data,textStatus,jqXHR){                                  
            }
        });
    }; 
   
    $("tr #cantidad").click(function(){
        var isbn2=$(this).parent().find("#isbn2").val();
        var cantidad=$(this).parent().find("#cantidad").val();
        var url="Controlador?accion=ActualziarCantidad";        
        $.ajax({
            type:'POST',
            url: url,
            data: "isbn2="+ isbn2 + "&cantidad=" + cantidad,
            success:function(data,textStatus,jqXHR){
                location.href="Controlador?accion=Carrito";
            }
        })
    })    
});

